﻿SET IDENTITY_INSERT [dbo].[Criptomoneda] ON
UPDATE [dbo].[Criptomoneda] SET CantidadAComprar=100 FROM [dbo].[Criptomoneda]
SET IDENTITY_INSERT [dbo].[Criptomoneda] OFF
