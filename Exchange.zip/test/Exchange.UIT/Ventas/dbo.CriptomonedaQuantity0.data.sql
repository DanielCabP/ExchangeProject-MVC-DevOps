﻿SET IDENTITY_INSERT [dbo].[Criptomoneda] ON
UPDATE [dbo].[Criptomoneda] SET CantidadAVender=0 FROM [dbo].[Criptomoneda]
SET IDENTITY_INSERT [dbo].[Criptomoneda] OFF
