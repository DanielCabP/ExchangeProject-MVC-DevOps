﻿SET IDENTITY_INSERT [dbo].[Red] ON
INSERT INTO [dbo].[Red] ([RedID], [nombre]) VALUES (1, N'Red Ethereum')
INSERT INTO [dbo].[Red] ([RedID], [nombre]) VALUES (2, N'Red Binance')
INSERT INTO [dbo].[Red] ([RedID], [nombre]) VALUES (3, N'Red Bitcoin')

SET IDENTITY_INSERT [dbo].[Red] OFF
SET IDENTITY_INSERT [dbo].[Criptomoneda] ON
INSERT INTO [dbo].[Criptomoneda] ([ID], [Nombre], [Precio], [PorcentajeVariacion], [Capitalizacion], [RedID], [CantidadAComprar], [NombreRed], [CantidadAVender]) VALUES (2, N'Bitcoin', 52353, -1, 988000000, 3, 1, 3, 1)
INSERT INTO [dbo].[Criptomoneda] ([ID], [Nombre], [Precio], [PorcentajeVariacion], [Capitalizacion], [RedID], [CantidadAComprar], [NombreRed], [CantidadAVender]) VALUES (4, N'BUSD', 1, -0.05, 11500000, 2, 30000, 2, 25000)
SET IDENTITY_INSERT [dbo].[Criptomoneda] OFF