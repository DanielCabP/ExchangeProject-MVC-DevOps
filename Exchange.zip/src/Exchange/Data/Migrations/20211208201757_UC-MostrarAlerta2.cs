﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Exchange.Data.Migrations
{
    public partial class UCMostrarAlerta2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_MonedaAlerta_Alerta_AlertaId",
                table: "MonedaAlerta");

            migrationBuilder.AlterColumn<int>(
                name: "AlertaId",
                table: "MonedaAlerta",
                type: "int",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AddColumn<int>(
                name: "ID",
                table: "MonedaAlerta",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddForeignKey(
                name: "FK_MonedaAlerta_Alerta_AlertaId",
                table: "MonedaAlerta",
                column: "AlertaId",
                principalTable: "Alerta",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_MonedaAlerta_Alerta_AlertaId",
                table: "MonedaAlerta");

            migrationBuilder.DropColumn(
                name: "ID",
                table: "MonedaAlerta");

            migrationBuilder.AlterColumn<int>(
                name: "AlertaId",
                table: "MonedaAlerta",
                type: "int",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AddForeignKey(
                name: "FK_MonedaAlerta_Alerta_AlertaId",
                table: "MonedaAlerta",
                column: "AlertaId",
                principalTable: "Alerta",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
