﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Exchange.Data.Migrations
{
    public partial class UCMostrarAlerta : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Alerta",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    FechaAlerta = table.Column<DateTime>(type: "datetime2", nullable: false),
                    FechaExpira = table.Column<DateTime>(type: "datetime2", nullable: false),
                    ClienteId = table.Column<string>(type: "nvarchar(450)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Alerta", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Alerta_AspNetUsers_ClienteId",
                        column: x => x.ClienteId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "MonedaAlerta",
                columns: table => new
                {
                    MonedaAlertaID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CriptomonedaId = table.Column<int>(type: "int", nullable: true),
                    AlertaId = table.Column<int>(type: "int", nullable: true),
                    NombreMonedaAlerta = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    PrecioAlerta = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MonedaAlerta", x => x.MonedaAlertaID);
                    table.ForeignKey(
                        name: "FK_MonedaAlerta_Alerta_AlertaId",
                        column: x => x.AlertaId,
                        principalTable: "Alerta",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_MonedaAlerta_Criptomoneda_CriptomonedaId",
                        column: x => x.CriptomonedaId,
                        principalTable: "Criptomoneda",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Alerta_ClienteId",
                table: "Alerta",
                column: "ClienteId");

            migrationBuilder.CreateIndex(
                name: "IX_MonedaAlerta_AlertaId",
                table: "MonedaAlerta",
                column: "AlertaId");

            migrationBuilder.CreateIndex(
                name: "IX_MonedaAlerta_CriptomonedaId",
                table: "MonedaAlerta",
                column: "CriptomonedaId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "MonedaAlerta");

            migrationBuilder.DropTable(
                name: "Alerta");
        }
    }
}
